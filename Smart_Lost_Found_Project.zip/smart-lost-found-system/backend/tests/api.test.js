const request = require('supertest');
const {app} = require('../src/server');
describe('Smart Lost & Found API',()=>{
 test('health endpoint returns service status',async()=>{const r=await request(app).get('/api/health');expect(r.statusCode).toBe(200);expect(r.body.ok).toBe(true);});
 test('items endpoint returns a list',async()=>{const r=await request(app).get('/api/items');expect(r.statusCode).toBe(200);expect(Array.isArray(r.body)).toBe(true);});
 test('report validation rejects missing fields',async()=>{const r=await request(app).post('/api/items').send({title:'Only title'});expect(r.statusCode).toBe(400);});
});
