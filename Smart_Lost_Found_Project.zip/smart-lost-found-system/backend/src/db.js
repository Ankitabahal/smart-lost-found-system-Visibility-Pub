const mysql = require('mysql2/promise');
const { MongoClient } = require('mongodb');
let mysqlPool;
let mongoClient;
async function connectDatabases() {
  if (process.env.MYSQL_HOST && process.env.MYSQL_DATABASE && process.env.MYSQL_USER) {
    mysqlPool = mysql.createPool({host:process.env.MYSQL_HOST,port:Number(process.env.MYSQL_PORT||3306),user:process.env.MYSQL_USER,password:process.env.MYSQL_PASSWORD,database:process.env.MYSQL_DATABASE,waitForConnections:true,connectionLimit:10});
    await mysqlPool.query('SELECT 1');
    console.log('MySQL connected');
  } else console.warn('MySQL not configured; using in-memory demo items.');
  if (process.env.MONGODB_URI) {
    mongoClient = new MongoClient(process.env.MONGODB_URI);
    await mongoClient.connect();
    console.log('MongoDB connected');
  } else console.warn('MongoDB not configured; activity logging disabled.');
}
function getPool(){return mysqlPool;}
function getMongoDb(){return mongoClient ? mongoClient.db(process.env.MONGODB_DATABASE||'smart_lost_found_logs') : null;}
module.exports={connectDatabases,getPool,getMongoDb};
