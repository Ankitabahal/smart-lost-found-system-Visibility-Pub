# Smart Lost & Found System

A full-stack academic project for a campus lost-and-found workflow.

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Relational data: MySQL (users, items, claims)
- Document data: MongoDB (activity logs and match metadata)
- Auth: JWT + bcrypt
- Tests: Jest + Supertest

## Features in this starter
- Responsive dashboard UI
- Search and filter demo items
- Report lost/found item form
- Express API with health, item listing, report creation and match suggestions
- MySQL schema and MongoDB connection setup
- Basic API tests and project documentation

> Academic starter: configure your own database credentials and test before production use. Notifications, full claim workflow, and real image storage are extension points, not yet production-ready.

## Run locally
### 1. Backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Set `MYSQL_HOST`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_DATABASE`, `MONGODB_URI`, and `JWT_SECRET` in `.env`.

### 2. Frontend
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Vite runs the UI locally and proxies `/api` requests to `http://localhost:5000`.

## Databases
Create a MySQL database using `backend/sql/schema.sql`. MongoDB stores optional activity/matching documents. The server starts in demo mode if database credentials are missing, but persistent writes require configured databases.
