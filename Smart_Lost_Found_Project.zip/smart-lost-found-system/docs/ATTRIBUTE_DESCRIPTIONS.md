# Attribute Descriptions

| Entity | Attribute | Description |
|---|---|---|
| User | id | Unique user identifier |
| User | name | Full name of campus member |
| User | email | Unique login email |
| User | password_hash | Hashed password; never store plain text passwords |
| User | role | `user` or `admin` |
| Item | id | Unique item report identifier |
| Item | user_id | User who submitted the report, nullable for imported records |
| Item | title | Short item name |
| Item | category | Category such as Electronics, Documents, Books, Accessories, Other |
| Item | report_type | `Lost` or `Found` |
| Item | location | Location where the item was lost/found |
| Item | description | Distinguishing details supplied by reporter |
| Item | image_url | Optional URL of uploaded image |
| Item | status | `Open`, `Claim Pending`, `Resolved`, or `Rejected` |
| Item | created_at | Report creation timestamp |
| Claim | id | Unique claim identifier |
| Claim | item_id | Item the claimant is asking about |
| Claim | claimant_id | User submitting the claim |
| Claim | details | Evidence/details to validate ownership |
| Claim | status | `Pending`, `Approved`, or `Rejected` |
| Claim | created_at | Claim creation timestamp |
