# Use Case Summary — Smart Lost & Found System

## Actors
- **Campus user:** student, faculty member, staff member, or visitor.
- **Administrator:** manages users, categories, records, claims, and reports.

## User use cases
1. Register and log in.
2. Report a lost item.
3. Report a found item.
4. Enter item details and optionally provide an image.
5. Search and filter item reports.
6. View possible matches.
7. Submit a claim and track its status.
8. View report and claim history and receive notifications.

## Administrator use cases
1. Sign in to the admin area.
2. Manage users and item categories.
3. Review lost/found reports and claims.
4. Verify or reject claims and update claim status.
5. Edit or remove item records and false/inappropriate entries.
6. Send notifications and view system statistics/reports.

## Core flows
- Report submission → validate details → save report → show report on community board.
- Lost/found report → compare category and description → suggest potential matches for user review.
- Claim submission → validate claim details → admin review → update status → notify claimant.
