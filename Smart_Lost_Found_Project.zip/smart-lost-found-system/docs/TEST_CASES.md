# Test Cases

| ID | Scenario | Input / precondition | Expected result |
|---|---|---|---|
| TC-01 | Health endpoint | GET `/api/health` | HTTP 200 and `ok: true` |
| TC-02 | List reports | GET `/api/items` | HTTP 200 with an array |
| TC-03 | Reject incomplete report | POST `/api/items` without location/type | HTTP 400 validation error |
| TC-04 | Create lost report | Valid title, location, type `Lost` | HTTP 201 and report payload |
| TC-05 | Create found report | Valid title, location, type `Found` | HTTP 201 and report payload |
| TC-06 | Search reports | Query a known item title | Only matching reports returned by configured filtering |
| TC-07 | Match suggestions | Request `/api/items/:id/matches` | Matching candidates returned for review |
| TC-08 | Database unavailable | Configure invalid database credentials | Service should fail startup with a clear database error |
| TC-09 | Responsive UI | Open frontend on mobile viewport | Navigation and cards fit screen without horizontal overflow |
| TC-10 | Claim validation | Submit claim with missing evidence | Claim API should reject request once claim workflow is implemented |

TC-01 through TC-03 have automated Jest/Supertest coverage. Other cases are manual or future-work cases until the corresponding workflow is implemented.
